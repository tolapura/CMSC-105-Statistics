package lab1_randomsampling;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Main extends JFrame{
    JLabel forBG;
    JButton RandomSampling, SystematicSampling, StratifiedSampling, Exit;

    public Main() {
        setLayout(null);
        setSize(400, 600);

        forBG = new JLabel("");
        forBG.setIcon(new ImageIcon(getClass().getResource("image.jpg")));
        forBG.setBounds(0, 0, 400, 600);

        RandomSampling = new JButton("Random Sampling");
        RandomSampling.setBounds(100, 200, 200, 40);

        SystematicSampling = new JButton("Systematic Sampling");
        SystematicSampling.setBounds(100, 270, 200, 40);

        StratifiedSampling = new JButton("Stratified Sampling");
        StratifiedSampling.setBounds(100, 340, 200, 40);

        Exit = new JButton("Exit");
        Exit.setBounds(100, 410, 200, 40);

        add(RandomSampling);
        add(SystematicSampling);
        add(StratifiedSampling);
        add(Exit);
        add(forBG);
        setResizable(false);
        setVisible(true);

        // Create the action listener to add to your buttons.
        ActionListener actionListener = new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                if (e.getSource() == RandomSampling) {
                    int i = getDataType();
                    RandomSampling RS = new RandomSampling(i);
                    RS.setVisible(true);
                    dispose();
                } else if (e.getActionCommand().equals("Systematic Sampling")) {
                    int i = getDataType();
                    SystematicSampling SP = new SystematicSampling(i);
                    SP.setVisible(true);
                    dispose();
                } else if (e.getActionCommand().equals("Stratified Sampling")) {
                    int i = getDataType();
                    StratifiedSampling SS = new StratifiedSampling(i);
                    SS.setVisible(true);
                    dispose();
                } else
                    System.exit(0);
            }
        };

        RandomSampling.addActionListener(actionListener);
        SystematicSampling.addActionListener(actionListener);
        StratifiedSampling.addActionListener(actionListener);
        Exit.addActionListener(actionListener);

    };

    public int getDataType(){
        JFrame frame = new JFrame();
        String code = " ";
        boolean errorIndex = false;
        do {
            code = JOptionPane.showInputDialog(
                    frame, "Enter the type of data. Type 1 for Character, 2 for Integer", "Select type of data",
                    JOptionPane.YES_OPTION
            );
            errorIndex = false;
            int convert = 0;
            try {
                convert = Integer.parseInt(code);
            } catch (NumberFormatException n) {
                errorIndex = true;
                //Will Throw exception!
                //do something! anything to handle the exception.
            }
            if(!errorIndex){
                if(!(Integer.parseInt(code) == 1 || Integer.parseInt(code) == 2)){
                   errorIndex = true;
                }
            }
        }while(errorIndex);
        return Integer.parseInt(code);
    }

    public static void main(String[] args){
        Main main = new Main();
    }
}
