package lab1_randomsampling;

import javax.swing.*;
import javax.swing.text.html.HTMLDocument;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.zip.CheckedInputStream;

public class RandomSampling extends JFrame{
    JFrame frame;
    JLabel forBG;
    int currIndex = 1;
    List<Integer> listOfInt = new ArrayList<Integer>();
    List<Character> listOfChar = new ArrayList<Character>();

    public RandomSampling(int i){
        setResizable(false);
        setVisible(true);
        setSize(400, 600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        frame = new JFrame("ERROR");
        forBG = new JLabel("");
        forBG.setIcon(new ImageIcon(getClass().getResource("random.jpg")));
        forBG.setBounds(0, 0, 400, 600);

        JTextField size = new JTextField();
        size.setVisible(true);
        size.setBounds(155, 40, 200, 25);

        JTextField data_type = new JTextField();
        data_type.setVisible(true);
        data_type.setBounds(155, 105, 200, 25);
        data_type.setText(i + " ");
        data_type.setEditable(false);

        JTextField inputs = new JTextField();
        inputs.setVisible(true);
        inputs.setBounds(155, 175, 200, 25);

        JTextArea inputsDisplay = new JTextArea();
        JScrollPane scroll2 = new JScrollPane(inputsDisplay);
        scroll2.setBounds(27, 215, 340, 105);
        inputsDisplay.setEditable(false);
        inputsDisplay.setLineWrap(true);

        JTextArea answerDisplay = new JTextArea();
        JScrollPane scroll = new JScrollPane(answerDisplay);
        scroll.setBounds(27, 430, 340, 105);
        answerDisplay.setEditable(true);
        answerDisplay.setLineWrap(true);

        JTextField sampleSize = new JTextField();
        sampleSize.setText("20");
        sampleSize.setVisible(true);
        sampleSize.setBounds(240, 390, 115, 25);

        JButton add = new JButton("ADD");
        add.setBounds(120, 325, 60, 25);

        JButton delete = new JButton("DELETE");
        delete.setBounds(190, 325, 80, 25);

        JButton edit = new JButton("EDIT");
        edit.setBounds(280, 325, 80, 25);

        JButton back = new JButton("BACK");
        back.setBounds(150, 540, 100, 25);

        JButton generate = new JButton("GENERATE");
        generate.setBounds(130, 390, 100, 25);

        add(back);
        add(generate);
        add(sampleSize);
        add(edit);
        add(delete);
        add(add);
        add(scroll);
        add(scroll2);
        add(inputs);
        add(size);
        add(data_type);
        add(forBG);

        ActionListener AL = new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (i == 2) {
                    if (e.getSource() == back) {
                        Main m = new Main();
                        m.setVisible(true);
                        dispose();
                    } else if (e.getSource() == add && inputs.getText().trim().length() != 0) {
                        String st_input = "";
                        boolean error = false;
                        try {
                            st_input = inputs.getText().trim();
                            int convert = Integer.parseInt(st_input);
                        } catch (NumberFormatException n) {
                            error = true;
                            //Will Throw exception!
                            //do something! anything to handle the exception.
                        }
                        if (!error) {
                            String st_display = inputsDisplay.getText();
                            st_display = st_display + "{" + currIndex + "," + st_input + "}" + "\n";
                            inputsDisplay.setText(st_display);
                            listOfInt.add(currIndex - 1, Integer.parseInt(st_input));
                            currIndex++;
                        } else {
                            //do nothing
                        }
                    } else if (e.getSource() == delete && listOfInt.size() != 0) {
                        String code = "";
                        code += JOptionPane.showInputDialog(
                                frame,
                                "Enter the index of the data you want to delete. Enter from 1 to " + listOfInt.size(),
                                "Delete data",
                                JOptionPane.YES_OPTION
                        );
                        boolean errorIndex = false;
                        int convert = 0;
                        try {
                            convert = Integer.parseInt(code);
                        } catch (NumberFormatException n) {
                            errorIndex = true;
                            //Will Throw exception!
                            //do something! anything to handle the exception.
                        }
                        if (!errorIndex) {
                            if (convert < 1 || convert > listOfInt.size()) {
                                JOptionPane.showMessageDialog(frame, "Invalid index!", "Error", JOptionPane.YES_OPTION);
                            } else {
                                Object obj = listOfInt.remove(convert - 1);
                                JOptionPane.showMessageDialog(frame, obj + " is removed!", "Deleted", JOptionPane.YES_OPTION);
                                String s = "";
                                int index = 1;
                                for (int i : listOfInt) {
                                    s += "{" + index + "," + i + "}" + "\n";
                                    index++;
                                }
                                inputsDisplay.setText(s);
                                currIndex--;
                            }
                        }

                    } else if (e.getSource() == edit && listOfInt.size() != 0) {
                        String code = "";
                        code = JOptionPane.showInputDialog(
                                frame,
                                "Enter the index of the data you want to change. Enter from 1 to " + listOfInt.size(),
                                "Change item",
                                JOptionPane.YES_OPTION
                        );
                        boolean errorIndex = false;
                        int convert = 0;
                        try {
                            convert = Integer.parseInt(code);
                        } catch (NumberFormatException n) {
                            errorIndex = true;
                            //Will Throw exception!
                            //do something! anything to handle the exception.
                        }
                        if (!errorIndex) {
                            if (convert < 1 || convert > listOfInt.size()) {
                                JOptionPane.showMessageDialog(frame, "Invalid index!", "Error", JOptionPane.YES_OPTION);
                            } else {
                                code = JOptionPane.showInputDialog(
                                        frame,
                                        "Enter the new value.",
                                        "Change item value",
                                        JOptionPane.YES_OPTION
                                );
                                boolean error = false;
                                int new_Value = 0;
                                try {
                                    new_Value = Integer.parseInt(code);
                                } catch (NumberFormatException n) {
                                    error = true;
                                    //Will Throw exception!
                                    //do something! anything to handle the exception.
                                }
                                if (!error) {
                                    listOfInt.set(convert - 1, new_Value);
                                    JOptionPane.showMessageDialog(frame, "Successfully changed value!", "Change item value", JOptionPane.YES_OPTION);
                                    String s = "";
                                    int index = 1;
                                    for (int i : listOfInt) {
                                        s += "{" + index + "," + i + "}" + "\n";
                                        index++;
                                    }
                                    inputsDisplay.setText(s);

                                } else {
                                    JOptionPane.showMessageDialog(frame, "Invalid value!", "Error", JOptionPane.YES_OPTION);
                                }

                            }
                        }

                    } else if (e.getSource() == generate) {
                        String errorMessage = "";
                        boolean errorDataType = false;
                        boolean errorSize = false;
                        try {
                            String frame_Size = size.getText().trim();
                            int convert = Integer.parseInt(frame_Size);
                        } catch (NumberFormatException n) {
                            errorSize = true;
                            //Will Throw exception!
                            //do something! anything to handle the exception.
                        }
                        if (errorSize || Integer.parseInt(size.getText().trim()) < 2 || Integer.parseInt(size.getText().trim()) > 10000) {
                            errorMessage = errorMessage + "Population size is not valid! Enter only a number between 25 and 10000.\n";
                        }

                        boolean errorSampleSize = false;
                        try {
                            String sample_Size = sampleSize.getText().trim();
                            int convert = Integer.parseInt(sample_Size);
                        } catch (NumberFormatException n) {
                            errorSampleSize = true;
                            //Will Throw exception!
                            //do something! anything to handle the exception.
                        }
                        if (sampleSize.getText().trim().compareTo("") == 0) {
                            sampleSize.setText("20");
                            errorSampleSize = false;
                        }
                        if (errorSampleSize || Integer.parseInt(sampleSize.getText().trim()) < 1 || Integer.parseInt(sampleSize.getText().trim()) > 100) {
                            errorMessage = errorMessage + "Sample size not valid!\n";
                        }

                        if ((!errorSize)) {
                            if (listOfInt.size() < Integer.parseInt(size.getText().trim())) {
                                errorMessage = errorMessage + "Data is lacking.\n";
                            } else if (listOfInt.size() > Integer.parseInt(size.getText().trim())) {
                                errorMessage = errorMessage + "You have reached the maximum.\n";
                            }
                        }
                        if (errorMessage.compareTo("") != 0) {
                            JOptionPane.showMessageDialog(frame, errorMessage, "Error", JOptionPane.YES_OPTION);
                        } else {

                            System.out.println("RANDOM" + "\n" + listOfInt.size());
                            float populationSize = (float) Integer.parseInt(size.getText().trim());
                            double k = Math.ceil((populationSize * (Integer.parseInt(sampleSize.getText().trim()) / 100.0f)));
                            System.out.println("Sample size: " + k);
                            if (k == populationSize) {
                                k--;
                            }
                            Integer[] arr = new Integer[listOfInt.size()];
                            for (int i = 0; i < arr.length; i++) {
                                arr[i] = i;
                            }
                            Collections.shuffle(Arrays.asList(arr));
                            String s = "";
                            List<Integer> temp = new ArrayList<Integer>();
                            for (int i = 0; i < k; i++) {
                                temp.add(arr[i]);
                            }
                            Collections.sort(temp);
                            for (int i : temp) {
                                s += "{" + (i + 1) + "," + listOfInt.get(i) + "}" + "\n";
                            }
                            answerDisplay.setText(s);
                        }

                    }
                } else {
                    if (e.getSource() == back) {
                        Main m = new Main();
                        m.setVisible(true);
                        dispose();
                    } else if (e.getSource() == add && inputs.getText().trim().length() != 0) {
                        String st_input = "";
                        boolean error = false;
                        char c = ' ';
                        st_input = inputs.getText().trim();
                        if (st_input.length() != 1) {
                            error = true;
                        } else {
                            c = st_input.charAt(0);
                            if (c >= 'a' && c <= 'z') {
                                error = false;
                            } else {
                                error = true;
                            }
                        }
                        if (!error) {
                            String st_display = inputsDisplay.getText();
                            st_display = st_display + "{" + currIndex + "," + st_input + "}" + "\n";
                            inputsDisplay.setText(st_display);
                            listOfChar.add(currIndex - 1, c);
                            currIndex++;
                        }
                    } else if (e.getSource() == delete && listOfChar.size() != 0) {
                        String code = "";
                        code += JOptionPane.showInputDialog(
                                frame,
                                "Enter the index of the data you want to delete. Enter from 1 to " + listOfChar.size(),
                                "Delete data",
                                JOptionPane.YES_OPTION
                        );
                        boolean errorIndex = false;
                        int convert = 0;
                        try {
                            convert = Integer.parseInt(code);
                        } catch (NumberFormatException n) {
                            errorIndex = true;
                            //Will Throw exception!
                            //do something! anything to handle the exception.
                        }
                        if (!errorIndex) {
                            if (convert < 1 || convert > listOfChar.size()) {
                                JOptionPane.showMessageDialog(frame, "Invalid index!", "Error", JOptionPane.YES_OPTION);
                            } else {
                                Object obj = listOfChar.remove(convert - 1);
                                JOptionPane.showMessageDialog(frame, obj + " is removed!", "Deleted", JOptionPane.YES_OPTION);
                                String s = "";
                                int index = 1;
                                for (char c : listOfChar) {
                                    s += "{" + index + "," + c + "}" + "\n";
                                    index++;
                                }
                                inputsDisplay.setText(s);
                                currIndex--;
                            }
                        }

                    } else if (e.getSource() == edit && listOfChar.size() != 0) {
                        String code = "";
                        code = JOptionPane.showInputDialog(
                                frame,
                                "Enter the index of the data you want to change. Enter from 1 to " + listOfChar.size(),
                                "Change item",
                                JOptionPane.YES_OPTION
                        );
                        boolean errorIndex = false;
                        int convert = 0;
                        try {
                            convert = Integer.parseInt(code);
                        } catch (NumberFormatException n) {
                            errorIndex = true;
                            //Will Throw exception!
                            //do something! anything to handle the exception.
                        }
                        if (!errorIndex) {
                            if (convert < 1 || convert > listOfChar.size()) {
                                JOptionPane.showMessageDialog(frame, "Invalid index!", "Error", JOptionPane.YES_OPTION);
                            } else {
                                code = JOptionPane.showInputDialog(
                                        frame,
                                        "Enter the new value.",
                                        "Change item value",
                                        JOptionPane.YES_OPTION
                                );
                                boolean error = false;
                                char c = ' ';
                                if (code.trim().length() != 1) {
                                    error = true;
                                } else {
                                    c = code.charAt(0);
                                    if (c >= 'a' && c <= 'z') {
                                        error = false;
                                    } else {
                                        error = true;
                                    }
                                }
                                if (!error) {
                                    listOfChar.set(convert - 1, c);
                                    JOptionPane.showMessageDialog(frame, "Successfully changed value!", "Change item value", JOptionPane.YES_OPTION);
                                    String s = "";
                                    int index = 1;
                                    for (char ch : listOfChar) {
                                        s += "{" + index + "," + ch + "}" + "\n";
                                        index++;
                                    }
                                    inputsDisplay.setText(s);

                                } else {
                                    JOptionPane.showMessageDialog(frame, "Invalid value!", "Error", JOptionPane.YES_OPTION);
                                }

                            }
                        }

                    } else if (e.getSource() == generate) {
                        String errorMessage = "";
                        boolean errorDataType = false;
                        boolean errorSize = false;
                        try {
                            String frame_Size = size.getText().trim();
                            int convert = Integer.parseInt(frame_Size);
                        } catch (NumberFormatException n) {
                            errorSize = true;
                            //Will Throw exception!
                            //do something! anything to handle the exception.
                        }
                        if (errorSize || Integer.parseInt(size.getText().trim()) < 25 || Integer.parseInt(size.getText().trim()) > 10000) {
                            errorMessage = errorMessage + "Population size is not valid! Enter only a number between 25 and 10000.\n";
                        }

                        boolean errorSampleSize = false;
                        try {
                            String sample_Size = sampleSize.getText().trim();
                            int convert = Integer.parseInt(sample_Size);
                        } catch (NumberFormatException n) {
                            errorSampleSize = true;
                            //Will Throw exception!
                            //do something! anything to handle the exception.
                        }
                        if (sampleSize.getText().trim().compareTo("") == 0) {
                            sampleSize.setText("20");
                            errorSampleSize = false;
                        }
                        if (errorSampleSize || Integer.parseInt(sampleSize.getText().trim()) < 1 || Integer.parseInt(sampleSize.getText().trim()) > 100) {
                            errorMessage = errorMessage + "Sample size not valid!\n";
                        }

                        if ((!errorSize)) {
                            if (listOfChar.size() < Integer.parseInt(size.getText().trim())) {
                                errorMessage = errorMessage + "Data is lacking.\n";
                            } else if (listOfChar.size() > Integer.parseInt(size.getText().trim())) {
                                errorMessage = errorMessage + "You have reached the maximum.\n";
                            }
                        }
                        if (errorMessage.compareTo("") != 0) {
                            JOptionPane.showMessageDialog(frame, errorMessage, "Error", JOptionPane.YES_OPTION);
                        } else {
                            float populationSize = (float) Integer.parseInt(size.getText().trim());
                            double k = Math.ceil((populationSize * (Integer.parseInt(sampleSize.getText().trim()) / 100.0f)));
                            if (k == populationSize) {
                                k--;
                            }
                            Integer[] arr = new Integer[listOfChar.size()];
                            for (int i = 0; i < arr.length; i++) {
                                arr[i] = i;
                            }
                            Collections.shuffle(Arrays.asList(arr));
                            String s = "RANDOM SAMPLE\n";
                            List<Integer> temp = new ArrayList<Integer>();
                            for (int i = 0; i < k; i++) {
                                temp.add(arr[i]);
                            }
                            Collections.sort(temp);
                            for (int i : temp) {
                                s += "{" + (i + 1) + "," + listOfChar.get(i) + "}" + "\n";
                            }
                            answerDisplay.setText(s);
                        }
                    }
                }
            }
        };
        back.addActionListener(AL);
        edit.addActionListener(AL);
        add.addActionListener(AL);
        delete.addActionListener(AL);
        generate.addActionListener(AL);
    }
}
